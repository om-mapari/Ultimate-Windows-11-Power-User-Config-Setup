// ==UserScript==
// @name         Hide Sonner Toast Notifications
// @namespace   CoderOM
// @match       https://www.transcribr.io/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description  Permanently hide all Sonner toast popups on the site
// ==/UserScript==



(function() {
    'use strict';

    const hideToasts = () => {
        const styles = `
            [data-sonner-toaster],
            .notification-toast,
            .sonner-toast,
            div[data-sonner-toaster] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }
        `;

        const styleElement = document.createElement('style');
        styleElement.innerHTML = styles;
        document.head.appendChild(styleElement);
    };

    hideToasts();

    // In case new toasts get added dynamically
    const observer = new MutationObserver(() => hideToasts());
    observer.observe(document.body, { childList: true, subtree: true });

})();
