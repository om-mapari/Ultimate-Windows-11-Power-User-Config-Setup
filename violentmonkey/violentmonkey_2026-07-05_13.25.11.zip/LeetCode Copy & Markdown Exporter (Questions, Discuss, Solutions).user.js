// ==UserScript==
// @name         LeetCode Copy & Markdown Exporter (Questions, Discuss, Solutions)
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Adds elegant copy buttons to LeetCode discuss posts, solutions, and questions (with old, new, and contest layouts) to copy raw Markdown/text.
// @author       Antigravity
// @match        *://leetcode.com/discuss/post/*
// @match        *://leetcode.com/discuss/topic/*
// @match        *://leetcode.com/discuss/interview-question/*
// @match        *://leetcode.com/problems/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // Config values with defaults (integrates with Tampermonkey/Violentmonkey menu)
    const config = {
        showCopyText: getSetting('showCopyText', true),
        showCopyMarkdown: getSetting('showCopyMarkdown', true),
        showCopyFullNote: getSetting('showCopyFullNote', true),
        showCopyComment: getSetting('showCopyComment', true),
    };

    function getSetting(key, defaultValue) {
        try {
            if (typeof GM_getValue !== 'undefined') {
                return GM_getValue(key, defaultValue);
            }
            const localVal = localStorage.getItem('lc_copy_' + key);
            return localVal !== null ? localVal === 'true' : defaultValue;
        } catch (e) {
            return defaultValue;
        }
    }

    function setSetting(key, value) {
        try {
            if (typeof GM_setValue !== 'undefined') {
                GM_setValue(key, value);
            } else {
                localStorage.setItem('lc_copy_' + key, value ? 'true' : 'false');
            }
        } catch (e) {
            console.error('Failed to save setting:', e);
        }
    }

    function registerMenuCommands() {
        if (typeof GM_registerMenuCommand === 'undefined') return;

        registerToggleCommand('showCopyText', 'Show "Copy Text" (Question page)');
        registerToggleCommand('showCopyMarkdown', 'Show "Copy Markdown" (Question/Discuss)');
        registerToggleCommand('showCopyFullNote', 'Show "Copy Full Note" (Discuss page)');
        registerToggleCommand('showCopyComment', 'Show "Copy Comment" (Comments)');
    }

    function registerToggleCommand(key, label) {
        const currentValue = config[key];
        const statusText = currentValue ? '✅ Enabled' : '❌ Disabled';
        GM_registerMenuCommand(`${label}: ${statusText}`, () => {
            const newValue = !currentValue;
            setSetting(key, newValue);
            config[key] = newValue;
            location.reload();
        });
    }

    // Initialize menu commands
    registerMenuCommands();

    // Inject styles
    const style = document.createElement('style');
    style.textContent = `
        /* Main explanation copy panel */
        .lc-copy-panel {
            position: absolute;
            top: 12px;
            right: 12px;
            z-index: 10;
            display: flex;
            gap: 8px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(0, 0, 0, 0.08);
            border-radius: 8px;
            padding: 4px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0.9;
        }
        .lc-copy-panel:hover {
            opacity: 1;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
            transform: translateY(-1px);
        }

        /* Dark Mode overrides */
        .dark .lc-copy-panel {
            background: rgba(38, 38, 38, 0.85);
            border-color: rgba(255, 255, 255, 0.08);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
        }
        .dark .lc-copy-panel:hover {
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.35);
        }

        /* Standard buttons */
        .lc-copy-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            font-size: 12px;
            font-weight: 400;
            height: 24px;
            padding: 0 10px;
            border-radius: 9999px;
            cursor: pointer;
            border: none !important;
            background: rgba(0, 0, 0, 0.05);
            color: rgb(60, 60, 67);
            transition: background 0.15s ease-in-out, color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, transform 0.1s ease;
            user-select: none;
            white-space: nowrap;
        }
        .lc-copy-btn:hover {
            background: rgba(0, 0, 0, 0.08);
            color: rgb(26, 26, 26);
        }
        .lc-copy-btn:active {
            transform: scale(0.97);
        }

        .dark .lc-copy-btn {
            background: rgba(255, 255, 255, 0.07) !important;
            color: rgb(230, 230, 230) !important;
        }
        .dark .lc-copy-btn:hover {
            background: rgba(255, 255, 255, 0.13) !important;
            color: rgb(255, 255, 255) !important;
        }

        /* Success states */
        .lc-copy-btn.success {
            background: rgba(46, 117, 89, 0.15) !important;
            color: rgb(46, 117, 89) !important;
        }
        .dark .lc-copy-btn.success {
            background: rgba(46, 117, 89, 0.25) !important;
            color: rgb(74, 174, 136) !important;
        }

        /* Error states */
        .lc-copy-btn.error {
            background: rgba(239, 68, 68, 0.15) !important;
            color: rgb(239, 68, 68) !important;
        }
        .dark .lc-copy-btn.error {
            background: rgba(239, 68, 68, 0.25) !important;
            color: rgb(248, 113, 113) !important;
        }

        /* Button content wrapper for smooth fade transitions */
        .lc-btn-content {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: inherit;
            transition: opacity 0.08s ease-in-out;
            opacity: 1;
            white-space: nowrap;
        }

        /* Make parent relative for proper absolute positioning */
        .break-words {
            position: relative !important;
        }

        /* Comment copy button integration */
        .lc-comment-wrapper {
            position: relative !important;
        }
        .lc-comment-copy-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            z-index: 5;
            opacity: 0;
            pointer-events: none;
            transition: all 0.2s ease;
        }
        .lc-comment-wrapper:hover .lc-comment-copy-btn {
            opacity: 0.8;
            pointer-events: auto;
        }
        .lc-comment-wrapper .lc-comment-copy-btn:hover {
            opacity: 1;
        }

        /* Question Header alignment */
        .lc-question-panel {
            display: inline-flex;
            gap: 6px;
            flex-shrink: 0;
            margin-left: auto;
            align-self: center;
        }

    `;
    document.head.appendChild(style);

    // Helper SVG icons
    const copyIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>`;
    const successIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
    const docIcon = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`;

    // Traverses React Fiber tree to extract prop values
    function getPropsFromFiber(element, checker) {
        if (!element) return null;
        const fiberKey = Object.keys(element).find(k => k.startsWith('__reactFiber$'));
        if (!fiberKey) return null;

        const queue = [element[fiberKey]];
        const visited = new Set();
        let depth = 0;

        while (queue.length > 0 && depth < 600) {
            depth++;
            const curr = queue.shift();
            if (!curr || visited.has(curr)) continue;
            visited.add(curr);

            const props = curr.memoizedProps || curr.pendingProps;
            if (props) {
                const res = checker(props);
                if (res) return res;
            }

            if (curr.return) queue.push(curr.return);
            if (curr.child) queue.push(curr.child);
            if (curr.sibling) queue.push(curr.sibling);
        }
        return null;
    }

    // Converts DOM HTML to clean markdown for LeetCode descriptions (handles superscripts, non-breaking spaces)
    function htmlToMarkdown(htmlElement) {
        if (!htmlElement) return '';

        const clone = htmlElement.cloneNode(true);

        function convertNode(node) {
            if (node.nodeType === 3) { // TEXT_NODE
                return node.nodeValue;
            }
            if (node.nodeType !== 1) { // ELEMENT_NODE
                return '';
            }

            const tagName = node.tagName.toUpperCase();
            let childrenMarkdown = '';

            for (const child of node.childNodes) {
                childrenMarkdown += convertNode(child);
            }

            switch (tagName) {
                case 'P':
                    return '\n\n' + childrenMarkdown.trim() + '\n\n';
                case 'STRONG':
                case 'B':
                    return `**${childrenMarkdown}**`;
                case 'EM':
                case 'I':
                    return `*${childrenMarkdown}*`;
                case 'SUP':
                    return `^${childrenMarkdown}`;
                case 'SUB':
                    return `_${childrenMarkdown}`;
                case 'CODE':
                    if (node.parentElement && node.parentElement.tagName.toUpperCase() === 'PRE') {
                        return childrenMarkdown;
                    }
                    return `\`${childrenMarkdown}\``;
                case 'PRE':
                    return `\n\`\`\`\n${childrenMarkdown.trim()}\n\`\`\`\n`;
                case 'UL':
                    return '\n' + childrenMarkdown + '\n';
                case 'LI':
                    return `\n- ${childrenMarkdown.trim()}`;
                case 'OL':
                    return '\n' + childrenMarkdown + '\n';
                case 'A':
                    const href = node.getAttribute('href') || '';
                    return `[${childrenMarkdown}](${href})`;
                case 'DIV':
                case 'SPAN':
                    return childrenMarkdown;
                case 'BR':
                    return '\n';
                default:
                    return childrenMarkdown;
            }
        }

        let markdown = convertNode(clone);
        // Replace non-breaking spaces with normal spaces
        markdown = markdown.replace(/\u00A0/g, ' ');
        // Clean up multiple newlines
        markdown = markdown.replace(/\n{3,}/g, '\n\n');
        return markdown.trim();
    }

    // Copies text to clipboard safely
    function copyToClipboard(text, button, labelText) {
        if (button.dataset.copying === 'true') return;
        button.dataset.copying = 'true';

        let contentSpan = button.querySelector('.lc-btn-content');
        if (!contentSpan) {
            contentSpan = document.createElement('span');
            contentSpan.className = 'lc-btn-content';
            contentSpan.innerHTML = button.innerHTML;
            button.innerHTML = '';
            button.appendChild(contentSpan);
        }

        // Freeze current width to prevent layout shift during text transition
        const currentWidth = button.getBoundingClientRect().width;
        button.style.width = `${currentWidth}px`;

        // Smoothly fade out the text
        contentSpan.style.opacity = '0';

        navigator.clipboard.writeText(text).then(() => {
            // Wait for fade-out to complete (80ms)
            setTimeout(() => {
                button.classList.add('success');
                contentSpan.innerHTML = `${successIcon} Copied!`;
                // Smoothly fade in the new text
                contentSpan.style.opacity = '1';

                // Hold success state for 1500ms
                setTimeout(() => {
                    // Smoothly fade out success text
                    contentSpan.style.opacity = '0';
                    // Wait for fade-out to complete (80ms)
                    setTimeout(() => {
                        button.classList.remove('success');
                        contentSpan.innerHTML = labelText;
                        // Smoothly fade back in original text
                        contentSpan.style.opacity = '1';
                        // Unfreeze width
                        button.style.width = '';
                        button.dataset.copying = 'false';
                    }, 80);
                }, 1500);
            }, 80);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            setTimeout(() => {
                button.classList.add('error');
                contentSpan.innerHTML = 'Error!';
                contentSpan.style.opacity = '1';
                setTimeout(() => {
                    contentSpan.style.opacity = '0';
                    setTimeout(() => {
                        button.classList.remove('error');
                        contentSpan.innerHTML = labelText;
                        contentSpan.style.opacity = '1';
                        button.style.width = '';
                        button.dataset.copying = 'false';
                    }, 80);
                }, 1500);
            }, 80);
        });
    }

    // Handles injecting buttons into the main discuss explanation or solutions post
    function injectMainExplanation() {
        const postBody = document.querySelector('div[class*="Body_markdown__"], div[class*="solution-markdown_markdown__"]');
        if (!postBody) return;

        // Parent break-words container
        const breakWordsContainer = postBody.closest('.break-words');
        if (!breakWordsContainer || breakWordsContainer.querySelector('.lc-copy-panel')) return;

        // Find metadata inside React Fiber
        const postDetail = getPropsFromFiber(postBody, (props) => {
            if (props && props.postDetail && typeof props.postDetail.content === 'string') {
                return props.postDetail;
            }
            if (props && props.solution && typeof props.solution.content === 'string') {
                return props.solution;
            }
            return null;
        });

        if (!postDetail) return;

        // Create Panel
        const panel = document.createElement('div');
        panel.className = 'lc-copy-panel';

        // Button 1: Copy Markdown content
        const copyMarkdownBtn = document.createElement('button');
        copyMarkdownBtn.className = 'lc-copy-btn';
        const mdLabel = `${copyIcon} Copy Raw Markdown`;
        copyMarkdownBtn.innerHTML = mdLabel;
        copyMarkdownBtn.addEventListener('click', () => {
            copyToClipboard(postDetail.content, copyMarkdownBtn, mdLabel);
        });

        // Button 2: Copy Full Formatted Note
        const copyNoteBtn = document.createElement('button');
        copyNoteBtn.className = 'lc-copy-btn';
        const noteLabel = `${docIcon} Copy Full Note`;
        copyNoteBtn.innerHTML = noteLabel;
        copyNoteBtn.addEventListener('click', () => {
            const tags = (postDetail.tags || []).map(t => t.name).join(', ');
            const author = postDetail.author ? `${postDetail.author.username} (${postDetail.author.realName || ''})` : 'Anonymous';
            const url = window.location.href;

            const fullNote = `# ${postDetail.title}

- **Author**: ${author}
- **LeetCode URL**: ${url}
- **Tags**: ${tags}

---

${postDetail.content}`;
            copyToClipboard(fullNote, copyNoteBtn, noteLabel);
        });

        if (config.showCopyMarkdown) {
            panel.appendChild(copyMarkdownBtn);
        }
        if (config.showCopyFullNote) {
            panel.appendChild(copyNoteBtn);
        }

        if (panel.children.length > 0) {
            breakWordsContainer.insertBefore(panel, breakWordsContainer.firstChild);
        }
    }

    // Handles injecting buttons into comments
    function injectCommentButtons() {
        const markdownDivs = document.querySelectorAll('div[class*="markdown-content"]');

        markdownDivs.forEach(div => {
            // Ignore the main post explanation
            if (div.className.includes('Body_markdown__') || div.className.includes('solution-markdown_markdown__')) return;

            // Make sure the comment parent is wrapped for hover button
            const wrapper = div.closest('.flex.flex-col.w-full');
            if (!wrapper || wrapper.querySelector('.lc-comment-copy-btn')) return;

            // Find comment details inside React Fiber
            const commentDetail = getPropsFromFiber(div, (props) => {
                if (props && props.comment && typeof props.comment.content === 'string') {
                    return props.comment;
                }
                return null;
            });

            if (!commentDetail) return;

            // Only inject comment copy button if enabled in settings
            if (!config.showCopyComment) return;

            wrapper.classList.add('lc-comment-wrapper');

            // Create Copy Button
            const copyBtn = document.createElement('button');
            copyBtn.className = 'lc-copy-btn lc-comment-copy-btn';
            const commentLabel = `${copyIcon} Copy Comment`;
            copyBtn.innerHTML = commentLabel;

            copyBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                copyToClipboard(commentDetail.content, copyBtn, commentLabel);
            });

            wrapper.appendChild(copyBtn);
        });
    }

    // Handles injecting copy buttons on the problem description page (supports dynamic, contest, and old layouts)
    function injectQuestionDescription() {
        const descEl = document.querySelector('[data-track-load="description_content"]') ||
                       document.querySelector('div.question-content.default-content') ||
                       document.querySelector('[class*="HTMLContent_html__"]');
        if (!descEl) return;

        // Try to identify the layout title container/parent (for extracting titleText)
        let titleContainer = document.querySelector('div.flex.w-full.flex-1.flex-col.gap-4.overflow-y-auto > div.flex.items-start.justify-between.gap-4') ||
                             document.querySelector('div.flex.items-start.justify-between.gap-4');

        if (!titleContainer) {
            // Contest page / Old layout fallback
            const titleEl = document.querySelector('[data-cy="question-title"]') ||
                            document.querySelector('.text-title-large') ||
                            document.querySelector('div.question-title h3') ||
                            document.querySelector('div.question-title') ||
                            document.querySelector('.question-title');
            if (titleEl) {
                titleContainer = titleEl.parentElement;
            }
        }
        if (!titleContainer) return;

        // Find the tags row (a flex gap-1 div) to inject our buttons
        // It's usually the second child of the main description container
        const container = document.querySelector('div.flex.w-full.flex-1.flex-col.gap-4.overflow-y-auto') || descEl.parentElement;
        if (!container) return;

        const tagsRow = Array.from(container.children).find(c => c.className.includes('flex gap-1') || c.className === 'flex gap-1');
        if (!tagsRow || tagsRow.querySelector('.lc-question-panel')) return;

        // Ensure tagsRow takes 100% width
        tagsRow.style.width = '100%';

        // Create Panel Container
        const panel = document.createElement('div');
        panel.className = 'lc-question-panel';

        // Button 1: Copy Plain Text Description
        const copyTextBtn = document.createElement('button');
        copyTextBtn.className = 'lc-copy-btn';
        const textLabel = `${copyIcon} Copy Text`;
        copyTextBtn.innerHTML = textLabel;
        copyTextBtn.addEventListener('click', () => {
            const titleLink = titleContainer.querySelector('a') || titleContainer.querySelector('h3') || titleContainer;
            const titleText = titleLink.textContent.trim().replace(/\s+/g, ' ');
            const plainText = `URL: ${window.location.href}\n\nTitle: ${titleText}\n\n${descEl.textContent.trim()}`;
            copyToClipboard(plainText, copyTextBtn, textLabel);
        });

        // Button 2: Copy Converted Markdown Note
        const copyMarkdownBtn = document.createElement('button');
        copyMarkdownBtn.className = 'lc-copy-btn';
        const mdLabel = `${docIcon} Copy Markdown`;
        copyMarkdownBtn.innerHTML = mdLabel;
        copyMarkdownBtn.addEventListener('click', () => {
            const titleLink = titleContainer.querySelector('a') || titleContainer.querySelector('h3') || titleContainer;
            const titleText = titleLink.textContent.trim().replace(/\s+/g, ' ');

            const diffEl = document.querySelector('div.flex.gap-1 > div.text-xs') ||
                           document.querySelector('.css-10o5uaw > div') ||
                           document.querySelector('[class*="text-brand-orange"]') ||
                           document.querySelector('[class*="text-yellow"]') ||
                           document.querySelector('[class*="text-green"]');
            const difficulty = diffEl ? diffEl.textContent.trim() : '';

            const markdown = htmlToMarkdown(descEl);

            const fullQuestion = `# ${titleText} ${difficulty ? `(${difficulty})` : ''}

- **LeetCode URL**: ${window.location.href}

---

${markdown}`;
            copyToClipboard(fullQuestion, copyMarkdownBtn, mdLabel);
        });

        if (config.showCopyText) {
            panel.appendChild(copyTextBtn);
        }
        if (config.showCopyMarkdown) {
            panel.appendChild(copyMarkdownBtn);
        }

        if (panel.children.length > 0) {
            tagsRow.appendChild(panel);
        }
    }

    // Run injection checks
    function checkAndInject() {
        injectMainExplanation();
        injectCommentButtons();
        injectQuestionDescription();
    }

    // SPA-friendly MutationObserver
    let throttleTimeout;
    const observer = new MutationObserver(() => {
        if (throttleTimeout) return;
        throttleTimeout = setTimeout(() => {
            checkAndInject();
            throttleTimeout = null;
        }, 100);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Run immediately
    checkAndInject();
})();
