// ==UserScript==
// @name         Excalidraw Entire Diagram Copier
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Injects a native "Copy Diagram" menu item directly below "Export image..." and registers Alt+C to copy the whole canvas as a serialized diagram.
// @author       Antigravity
// @match        https://app.excalidraw.com/*
// @match        https://excalidraw.com/*
// @grant        GM_setClipboard
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // 1. Toast styling matching Excalidraw's theme natively
    const toastStyles = `
        .excalidraw .excal-copier-toast {
            position: absolute;
            top: 24px;
            right: 24px;
            z-index: 9999999;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 20px;
            background: var(--input-bg-color, #121214);
            border: 1px solid var(--input-border-color, rgba(255, 255, 255, 0.08));
            border-radius: 12px;
            color: var(--icon-fill-color, #ffffff);
            font-family: var(--ui-font, sans-serif);
            font-size: 14px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            opacity: 0;
            transform: translateY(-20px) scale(0.95);
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            pointer-events: auto !important;
        }
        .excalidraw .excal-copier-toast.show {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        .excalidraw .excal-copier-toast-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            border-radius: 50%;
        }
        .excalidraw .excal-copier-toast-success .excal-copier-toast-icon {
            background: rgba(76, 175, 80, 0.2);
            color: #4caf50;
        }
        .excalidraw .excal-copier-toast-error .excal-copier-toast-icon {
            background: rgba(244, 67, 54, 0.2);
            color: #f44336;
        }
    `;

    // Inject styles in Document Head
    function injectStyles() {
        if (document.getElementById('excal-copier-styles')) return;
        const styleEl = document.createElement('style');
        styleEl.id = 'excal-copier-styles';
        styleEl.innerHTML = toastStyles;
        document.head.appendChild(styleEl);
    }

    // High-fidelity dynamic Toast Notifications
    function showToast(message, type = "success") {
        const container = document.querySelector('.excalidraw');
        if (!container) return;

        const existing = container.querySelectorAll('.excal-copier-toast');
        existing.forEach(t => t.remove());

        const toast = document.createElement('div');
        toast.className = `excal-copier-toast excal-copier-toast-${type}`;

        const iconHtml = type === "success"
            ? `<div class="excal-copier-toast-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg></div>`
            : `<div class="excal-copier-toast-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></div>`;

        toast.innerHTML = `
            ${iconHtml}
            <span style="font-weight: 600;">${message}</span>
        `;

        container.appendChild(toast);

        setTimeout(() => toast.classList.add('show'), 10);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 3000);
    }

    // Traverse React Fiber to get scene properties
    function getReactProps() {
        const el = document.querySelector('.layer-ui__wrapper');
        if (!el) return null;

        const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactContainer$'));
        if (!fiberKey) return null;

        let current = el[fiberKey];
        while (current) {
            if (current.memoizedProps && current.memoizedProps.actionManager) {
                return current.memoizedProps;
            }
            current = current.return;
        }
        return null;
    }

    // Main Copy Diagram logic (uses the exact same serialized state elements as save action)
    async function copyDiagram() {
        try {
            const props = getReactProps();
            if (!props || !props.elements) {
                showToast("No diagram data found.", "error");
                return;
            }

            const activeElements = props.elements.filter(e => !e.isDeleted);
            if (activeElements.length === 0) {
                showToast("No elements found in active diagram.", "error");
                return;
            }

            // Excalidraw clipboard format wrapping the raw elements and files
            const clipboardObj = {
                type: "excalidraw/clipboard",
                elements: activeElements,
                files: props.files || {}
            };

            const jsonText = JSON.stringify(clipboardObj);
            let success = false;

            try {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    await navigator.clipboard.writeText(jsonText);
                    success = true;
                }
            } catch (e) {
                console.warn("navigator.clipboard failed, using GM fallback", e);
            }

            if (!success && typeof GM_setClipboard === 'function') {
                GM_setClipboard(jsonText, 'text/plain');
                success = true;
            }

            if (success) {
                showToast(`Copied ${activeElements.length} elements to clipboard!`, "success");
            } else {
                showToast("Could not copy diagram to clipboard.", "error");
            }
        } catch (err) {
            console.error("Excalidraw Copier Error:", err);
            showToast("Error copying diagram.", "error");
        }
    }

    // Inject "Copy Diagram" directly below "Export image..." in the Radix Hamburger menu
    function injectMenuItem() {
        const menuItems = Array.from(document.querySelectorAll('.dropdown-menu-item'));
        const exportItem = menuItems.find(el => el.innerText.includes('Export image'));

        if (exportItem) {
            // Avoid duplicate injection
            const alreadyExists = menuItems.some(el => el.innerText.includes('Copy Diagram'));
            if (alreadyExists) return;

            injectStyles();

            // Clone the native "Export image" menu item to maintain 100% native layout & styles
            const copyItem = exportItem.cloneNode(true);

            copyItem.setAttribute('aria-label', 'Copy Diagram');
            copyItem.setAttribute('title', 'Copy Diagram (Alt+C)');
            copyItem.setAttribute('data-testid', 'copy-diagram-button');

            // Set labels
            const textSpan = copyItem.querySelector('.dropdown-menu-item__text span');
            if (textSpan) textSpan.innerText = 'Copy Diagram';

            const shortcutDiv = copyItem.querySelector('.dropdown-menu-item__shortcut');
            if (shortcutDiv) shortcutDiv.innerText = 'Alt+C';

            // Set SVG icon
            const iconDiv = copyItem.querySelector('.dropdown-menu-item__icon');
            if (iconDiv) {
                iconDiv.innerHTML = `
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                    </svg>
                `;
            }

            // Assign click callback
            copyItem.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                copyDiagram();

                // Close hamburger menu natively using Escape keypress event
                document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
            };

            // Insert directly below the Export Image item
            exportItem.parentNode.insertBefore(copyItem, exportItem.nextSibling);
        }
    }

    // Monitor DOM for menu mounting
    const observer = new MutationObserver(() => {
        injectMenuItem();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Keyboard listener for instant trigger
    window.addEventListener('keydown', (e) => {
        if (e.altKey && e.key.toLowerCase() === 'c') {
            e.preventDefault();
            copyDiagram();
        }
    });

})();