// ==UserScript==
// @name         Disable D Key Debug Panel
// @namespace    CoderOM
// @version      1.0
// @description  Stop debug panel opening when pressing D key
// @match        https://learn.kodekloud.com/user/courses/*
// @grant        none
// @author       CoderOM
// ==/UserScript==


(function () {

    console.log("🔥 Force expanding debug panel before closing...");

    function expandShadow(root) {
        if (!root) return;

        // Force hover & focus events on panel container
        const panels = root.querySelectorAll('div[class*="DebugPanel_module_root"]');

        panels.forEach(panel => {
            panel.dispatchEvent(new Event("mouseenter", { bubbles: true }));
            panel.dispatchEvent(new Event("mouseover", { bubbles: true }));
            panel.dispatchEvent(new Event("focusin", { bubbles: true }));

            console.log("✨ Forced panel expansion");
        });
    }

    function closePanel() {

        expandShadow(document);

        setTimeout(() => {
            const btn = document.querySelector('button[aria-label="Close stats debug panel"]')
                        || document.querySelector('button[class*="DebugPanel_module_closeButton"]');

            if (btn) {
                console.log("🔥 Found & Clicking Close Button");
                btn.click();
            } else {
                console.log("⛔ Still not visible - waiting...");
            }
        }, 120);
    }


    // When user presses D, force-close it shortly after
    window.addEventListener("keydown", () => {
        setTimeout(closePanel, 100);
        setTimeout(closePanel, 300);
        setTimeout(closePanel, 600);
    }, true);

    // Periodically try closing
    setInterval(closePanel, 800);

})();
