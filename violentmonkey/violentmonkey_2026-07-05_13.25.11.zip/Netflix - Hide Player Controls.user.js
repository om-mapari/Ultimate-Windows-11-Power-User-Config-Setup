// ==UserScript==
// @name         Netflix - Hide Player Controls
// @namespace    http://www.xyz.net/
// @version      1.0
// @description  Press "g" to hide/show Netflix video controls
// @author       CoderOm
// @match                https://www.netflix.com/*
// @grant        none
// ==/UserScript==

(function () {
  "use strict";

  const HIDE_CLASS = "om-hide-controls";
  const DATA_ATTR = "data-om-controls-hidden";
  const CHECK_INTERVAL_MS = 500;
  let isHidden = false;
  let initialized = false;
  let observer = null;
  let poller = null;

  // NOTE: *** NO SUBTITLE SELECTOR HERE ***
  const HIDE_CSS = `
    .${HIDE_CLASS} .watch-video--bottom-controls-container,
    .${HIDE_CLASS} [data-uia="controls-standard"],
    .${HIDE_CLASS} .watch-video--back-container,
    .${HIDE_CLASS} .watch-video--flag-container,
    .${HIDE_CLASS} [data-uia="timeline"],
    .${HIDE_CLASS} [data-uia^="control-"],
    .${HIDE_CLASS} [data-uia="controls-time-remaining"],
    .${HIDE_CLASS} .default-ltr-iqcdef-cache-100d0a9,
    .${HIDE_CLASS} .default-ltr-iqcdef-cache-1wnafyo {
      visibility: hidden !important;
      pointer-events: none !important;
      opacity: 0 !important;
    }
  `;

  function injectCss() {
    if (document.getElementById("om-hide-controls-style")) return;
    const style = document.createElement("style");
    style.id = "om-hide-controls-style";
    style.textContent = HIDE_CSS;
    document.head?.appendChild(style);
  }

  function findPlayerContainer() {
    const selectors = [
      ".watch-video",
      "[data-uia='player']",
      ".watch-video--player-view",
      "#video-player",
    ];
    for (const s of selectors) {
      const el = document.querySelector(s);
      if (el) return el;
    }
    return null;
  }

  function toggleControls(forceHide) {
    const player = findPlayerContainer();
    if (!player) return false;

    if (typeof forceHide === "boolean") isHidden = forceHide;
    else isHidden = !isHidden;

    if (isHidden) {
      player.classList.add(HIDE_CLASS);
      player.setAttribute(DATA_ATTR, "true");
    } else {
      player.classList.remove(HIDE_CLASS);
      player.setAttribute(DATA_ATTR, "false");
    }
    return true;
  }

  function onKey(e) {
    const tag = (document.activeElement && document.activeElement.tagName) || "";
    if (tag === "INPUT" || tag === "TEXTAREA" || document.activeElement?.isContentEditable) return;
    if (e.key && e.key.toLowerCase() === "g") {
      const ok = toggleControls();
      if (!ok) scanForPlayerAndInit();
    }
  }

  function onDomMutation() {
    if (initialized) return;
    const player = findPlayerContainer();
    if (player) setupForPlayer(player);
  }

  function setupForPlayer(player) {
    initialized = true;
    injectCss();

    if (isHidden) {
      player.classList.add(HIDE_CLASS);
      player.setAttribute(DATA_ATTR, "true");
    } else {
      player.classList.remove(HIDE_CLASS);
      player.setAttribute(DATA_ATTR, "false");
    }

    if (observer) {
      observer.disconnect();
      observer = null;
    }

    const smallObserver = new MutationObserver((mutList) => {
      for (const m of mutList) {
        if (m.type === "childList" && !document.body.contains(player)) {
          initialized = false;
          startGlobalObserver();
          setTimeout(scanForPlayerAndInit, 200);
          smallObserver.disconnect();
          break;
        }
      }
    });
    smallObserver.observe(document.body, { childList: true, subtree: true });
  }

  function startGlobalObserver() {
    if (observer) return;
    observer = new MutationObserver(() => onDomMutation());
    observer.observe(document.body, { childList: true, subtree: true });

    if (!poller) {
      poller = setInterval(() => {
        if (!initialized) onDomMutation();
      }, CHECK_INTERVAL_MS);
    }
  }

  function scanForPlayerAndInit() {
    const player = findPlayerContainer();
    if (player) setupForPlayer(player);
  }

  function hookHistoryEvents() {
    const wrap = (orig) =>
      function () {
        const res = orig.apply(this, arguments);
        window.dispatchEvent(new Event("om-spa-navigated"));
        return res;
      };

    history.pushState = wrap(history.pushState);
    history.replaceState = wrap(history.replaceState);

    window.addEventListener("popstate", () =>
      window.dispatchEvent(new Event("om-spa-navigated"))
    );

    window.addEventListener("om-spa-navigated", () => {
      initialized = false;
      setTimeout(scanForPlayerAndInit, 300);
    });
  }

  function attachGlobalHandlers() {
    if (window.__om_hide_controls_installed) return;
    window.__om_hide_controls_installed = true;

    document.addEventListener("keydown", onKey, true);
    hookHistoryEvents();
    startGlobalObserver();
    scanForPlayerAndInit();
  }

  (function start() {
    injectCss();
    attachGlobalHandlers();
  })();
})();